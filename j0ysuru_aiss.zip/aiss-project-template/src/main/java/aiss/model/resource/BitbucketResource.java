package aiss.model.resource;

import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.bitbucket.Owner;
import aiss.model.bitbucket.Repos;

public class BitbucketResource {
	private static final Logger log = Logger.getLogger(BitbucketResource.class.getName());

    private final String access_token;
    private final String uri = "https://api.bitbucket.org/2.0/";
    
  
    

    public BitbucketResource(String access_token) {
        this.access_token = access_token;
    }
    public Repos getRepos() {
    	ClientResource cr = null;
        Repos repos = null;
        try {
//        	log.warning(access_token);
//            cr = new ClientResource(uri + "user/?access_token="+access_token);
//            Owner users = cr.get(Owner.class);
//            String username = users.getUsername();
//            log.warning(username);
            cr = new  ClientResource(uri+ "repositories/"+"j0ysuru"); 
            repos = cr.get(Repos.class);
        } catch (ResourceException re) {
            log.warning("Error when retrieving all files: " + cr.getResponse().getStatus());
        }

        return repos;
    }
    public Owner getUserInfo() {
    	ClientResource cr = null;
        Owner user = null;
        try {
        	log.warning(access_token);
            cr = new ClientResource(uri+"user/?access_token="+access_token);
            user = cr.get(Owner.class);

        } catch (ResourceException re) {
            log.warning("Error when retrieving all files: " + cr.getResponse().getStatus());
        }

        return user;
    }
    
}
