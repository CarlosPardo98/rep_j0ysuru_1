package aiss.bitbucket.controller;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import aiss.model.bitbucket.Owner;

import aiss.model.resource.BitbucketResource;


/**
 * Servlet implementation class UserInfo
 */
public class UserInfo extends HttpServlet {
	private static final Logger log = Logger.getLogger(UserInfo.class.getName());

       
    
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

        String accessToken = (String) req.getSession().getAttribute("Bitbucket-token");

        if (accessToken != null && !"".equals(accessToken)) {

            BitbucketResource bbResource = new BitbucketResource(accessToken);
            Owner user = bbResource.getUserInfo();

            if (user != null) {
                req.setAttribute("user", user);
                resp.sendRedirect(req.getContextPath()+"/RepoListController");
            } else {
                log.info("suda");
                req.getRequestDispatcher("/AuthController/Bitbucket").forward(req, resp);
            }
        } else {
            log.info("Trying to access Google Drive without an access token, redirecting to OAuth servlet");
            req.getRequestDispatcher("/AuthController/Bitbucket").forward(req, resp);
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
